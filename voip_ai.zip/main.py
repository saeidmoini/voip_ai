import logging
import sys
import os
from config import API_KEY, logger
from asterisk.agi import AGI
from src.audio import record_audio
from src.openai_module import AvalAiApi

def main():
    logger.info("App Started")
    #agi = AGI()
    #agi.answer()
    api = AvalAiApi(API_KEY)
    #api.tts("سلام لطفا کد سردخونه را اعلام کنید", 'hello')
    audio_file = "./logs/whatsup"
    os.makedirs(os.path.dirname(audio_file), exist_ok=True)
    # record_audio(agi, audio_file)
    user_text = api.stt(audio_file+".wav")


    describe = "What is the cold storage code number in this text? If it exists say: کد شما {provided the number} هست; \n if not, just answer: لطفا دوباره تلاش کنید (answer just in persian) <br>"
    answer = api.chatting(describe + user_text)
    print(answer.content)

    #agi.verbose("python agi Done")
    #agi.hangup()


if __name__ == "__main__":
    main()
