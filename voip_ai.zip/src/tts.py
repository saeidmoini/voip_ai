import logging
from openai import OpenAI

def text_to_speech(text, api_key):
    client = OpenAI(
    base_url="https://api.avalai.ir/v1",
    api_key=api_key
    )
    speech_file_path = "./logs/speech.mp3"
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input=text,
    )
    response.stream_to_file(speech_file_path) 
