from openai import OpenAI
from pydub import AudioSegment
import logging
from langchain_openai import ChatOpenAI

logger = logging.getLogger('agi_logger')


class AvalAiApi:
    def __init__(self, API_KEY):
        self.client = OpenAI(
            base_url="https://api.avalai.ir/v1",
            api_key=API_KEY
        )
        self.chat = ChatOpenAI(model="gpt-3.5-turbo", base_url="https://api.avalai.ir/v1", api_key=API_KEY)
        self.history = []

    def tts(self, text, file_name):
        logger.info("TTS Started")
        speech_file_path = f"./logs/{file_name}.mp3"
        wav_file = f"./logs/{file_name}.wav"
        response = self.client.audio.speech.create(
            model="tts-1",
            voice="alloy",
            input=text,
        )
        response.stream_to_file(speech_file_path)
        self.convert_mp3_to_wav(speech_file_path, wav_file)

    def stt(self, audio_file):
        logger.info(f"Sending {audio_file} for API")
        with open(audio_file, "rb") as audio:
            transcription = self.client.audio.transcriptions.create(
                model="whisper-1",
                file=audio,
                response_format="text"
            )
        return transcription
    def chatting(self, text):
        # Append the new message to history
        self.history.append({"role": "user", "content": text})
        # Call the API with the entire conversation history
        response = self.chat.invoke(self.history)

        # Append AI's response to the history
        self.history.append({"role": "assistant", "content": response.content})
        return response

    def convert_mp3_to_wav(self, mp3_file, wav_file):
        try:
            # Load the MP3 file
            audio = AudioSegment.from_mp3(mp3_file)

            # Export the audio as a WAV file
            audio.export(wav_file, format="wav")
            logger.info(f"Successfully converted {mp3_file} to {wav_file}")
        except Exception as e:
            logger.info(f"Error converting {mp3_file}: {e}")