import logging

API_KEY = "aa-4xhO0hL9vzi7m8fCOLZqY5G02fcsfCyWL2jbmC9nzUlJkprC"

import os
log_file_path = "./logs/debug.log"
os.makedirs(os.path.dirname(log_file_path), exist_ok=True)
logger = logging.getLogger('agi_logger')
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler(log_file_path)
file_handler.setLevel(logging.INFO)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)
logger.addHandler(file_handler)
logger.addHandler(console_handler)